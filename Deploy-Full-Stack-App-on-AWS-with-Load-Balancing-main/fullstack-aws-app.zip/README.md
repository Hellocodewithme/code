# 🚀 Full Stack App Deployment on AWS with Load Balancing

## 📦 Project Structure
```
fullstack-aws-app/
├── client/    # React frontend (served via Nginx)
└── server/    # Node.js backend (served on EC2 behind ALB)
```

## 🧰 Steps to Deploy

### 1️⃣ Backend Deployment
1. Launch **2+ EC2 instances** for backend
2. Install Docker:
   ```bash
   sudo apt update
   sudo apt install -y docker.io
   sudo systemctl start docker
   ```
3. Build & run:
   ```bash
   docker build -t backend-app .
   docker run -d -p 5000:5000 backend-app
   ```

### 2️⃣ Frontend Deployment
1. Launch another EC2 instance for frontend
2. Update your React `.env` file:
   ```bash
   REACT_APP_API_URL=http://<ALB-DNS-NAME>
   ```
3. Build & run container:
   ```bash
   docker build -t frontend-app .
   docker run -d -p 80:80 frontend-app
   ```

### 3️⃣ Application Load Balancer (ALB)
1. Go to AWS Console → **EC2 → Load Balancers**
2. Create **Application Load Balancer**
3. Create a **Target Group** (port 5000) and attach backend EC2s
4. Add Listener (HTTP 80) forwarding to Target Group

### 4️⃣ Optional: Route 53 Domain Setup
- Create A record pointing to ALB DNS name

### ✅ Expected Output
- Full stack app accessible via public URL
- ALB distributes traffic evenly to backend EC2 instances
- Scalable and fault-tolerant deployment
