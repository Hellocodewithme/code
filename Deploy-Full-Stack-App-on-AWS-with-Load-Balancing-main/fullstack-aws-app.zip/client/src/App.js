import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h1>🚀 Full Stack App on AWS with Load Balancing</h1>
      <p>Frontend served via Nginx | Backend via AWS ALB</p>
    </div>
  );
}

export default App;
