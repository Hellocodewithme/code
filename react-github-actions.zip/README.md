# React CI/CD with GitHub Actions

This project demonstrates how to set up a **CI/CD pipeline** using **GitHub Actions**.

## 🚀 Features
- Runs on every push to the main branch.
- Installs dependencies, runs tests, and builds the app.
- Uploads build artifacts automatically.
- Optional deployment to GitHub Pages.

## ⚙️ Setup
1. Push this repo to GitHub.
2. Go to the "Actions" tab to see your workflow in action.
3. To enable deployment, uncomment the deployment section in `.github/workflows/main.yml`.

## 🧪 Commands
```bash
npm install
npm test
npm run build
```
