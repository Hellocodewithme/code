# 🐳 Dockerized React App (Multi-Stage Build)

## 🚀 Objective
Build a production-ready Docker image using **multi-stage builds** with Node.js and Nginx.

## 📦 Setup Instructions

### 1️⃣ Build Docker image
```bash
cd frontend
docker build -t react-dockerized-app .
```

### 2️⃣ Run container
```bash
docker run -d -p 80:80 react-dockerized-app
```

### 3️⃣ Open in browser
Go to [http://localhost](http://localhost)

You’ll see the message:
> “🚀 React App Dockerized with Multi-Stage Build”

## 🧠 Notes
- The build stage uses Node.js to compile React.
- The final image uses **Nginx** (no Node.js runtime) for a lightweight production image.
- `.dockerignore` ensures unnecessary files are excluded.

### ✅ Expected Output
- Small final image (under 100MB)
- App served correctly via Nginx
