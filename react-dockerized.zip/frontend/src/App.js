import React from 'react';

function App() {
  return (
    <div style={styles.container}>
      <h1>🚀 React App Dockerized with Multi-Stage Build</h1>
      <p>This app is running inside a lightweight Nginx container!</p>
    </div>
  );
}

const styles = {
  container: {
    textAlign: 'center',
    marginTop: '100px',
    fontFamily: 'Arial, sans-serif'
  }
};

export default App;
